import { createBrowserRouter } from 'react-router';
import RootLayout from './components/layout/RootLayout';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import FloorPlannerPage from './pages/FloorPlannerPage';
import InteriorDesignPage from './pages/InteriorDesignPage';
import ExteriorDesignPage from './pages/ExteriorDesignPage';
import ProfilePage from './pages/ProfilePage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootLayout,
    children: [
      { index: true, Component: LandingPage },
      { path: 'dashboard', Component: Dashboard },
      { path: 'floor-planner', Component: FloorPlannerPage },
      { path: 'interior', Component: InteriorDesignPage },
      { path: 'exterior', Component: ExteriorDesignPage },
      { path: 'profile', Component: ProfilePage },
    ],
  },
]);
